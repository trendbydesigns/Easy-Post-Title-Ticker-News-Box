<?php

/*
Plugin Name: Easy-Post-Title-Ticker-News-Box
Plugin URI: https://trendbydesigns.com/easy-news-ticker-post-box/
Description: Easy-Post-title-Ticker-News-Box  A jQuery and Bootstrap 3 based plugin for creating a clean responsive post-title-Ticker/slider that allows you to vertically scroll html contents with autoplay and up/down navigation support.
Version: 1.0.0
Author: William Stancil 
Author URI: https://trebdbydesigns.com/about-us
License: GPLv2 or later
Text Domain: Easy-Post-Title-Ticker-News-Box
*/


function post_title_latest_jquery() {
	wp_enqueue_script('jquery');
}
add_action('init', 'post_title_latest_jquery');




function post_title_Picker_js()
{
    // Register the script like this for a plugin:
    wp_register_script( 'pluginsmain-script', plugins_url( '/js/jquery.bootstrap.newsbox.min.js', __FILE__ ), array( 'jquery' ) );

    // For either a plugin or a theme, you can then enqueue the script:
    wp_enqueue_script( 'pluginsmain-script' );

}
add_action( 'wp_enqueue_scripts', 'post_title_Picker_js' );



function post_title_plugin_main_style() {
	wp_enqueue_style( 'post_title_main_style-css', plugins_url( '/css/bootstrap.min.css', __FILE__ ));
	wp_enqueue_style( 'bootstrap-css', plugins_url( '/css/bootstrap-theme.min.css', __FILE__ ));
	wp_enqueue_style( 'sitecss', plugins_url( '/css/site.css', __FILE__ ));
}
add_action('init','post_title_plugin_main_style');



add_action( 'init', 'ticker_image_size' );
function ticker_image_size() {
    add_image_size( 'ticker_image', 90, 90, true ); //mobile
}




function post_title_Picker_active () {?>
	<script type="text/javascript">
	jQuery(function () {
	jQuery(".demo").bootstrapNews({
	newsPerPage: 4,
	navigation: true,
	autoplay: true,
	direction:'up', // up or down
	animationSpeed: 'normal',
	newsTickerInterval: 4000, //4 secs
	pauseOnHover: true,
	onStop: null,
	onPause: null,
	onReset: null,
	onPrev: null,
	onNext: null,
	onToDo: null
	});
	});
	</script>
<?php
}
add_action('wp_head','post_title_Picker_active');



// create shortcode to list all clothes which come in blue
add_shortcode( 'ticker', 'rmcc_post_listing_shortcode1' );
function rmcc_post_listing_shortcode1( $atts ) {
    ob_start();
    $query = new WP_Query( array(
        'post_type' => 'post',
        'posts_per_page' => -1,
    ) );
    if ( $query->have_posts() ) { ?>
	
 							<div class="panel panel-default">
							<div class="panel-heading"> <span class="glyphicon glyphicon-list-alt"></span><b>News</b></div>
							<div class="panel-body">
							<div class="row">
							<div class="col-xs-12">
							<ul class="demo">	
								<?php while ( $query->have_posts() ) : $query->the_post(); ?>
								<li class="news-item">
								<table cellpadding="4">
								<tr>
									<td width="100" ><?php the_post_thumbnail('ticker_image') ?></td>
									<td>
										<?php the_excerpt(); ?>...<a href="<?php the_permalink(); ?>">>Read more...</a>
									</td>
								</tr>
								</table>
								</li>
            <?php endwhile;
            wp_reset_postdata(); ?>
							</ul>
							</div>
							</div>
							</div>
							<div class="panel-footer"> </div>
							</div>
		
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }
}

?>